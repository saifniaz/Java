import java.util.ArrayList;

class DoubleLinkedListIterator{
	
	public DoubleLinkedList dll;
	
	public DoubleLinkedListIterator(DoubleLinkedList dll){
		this.dll = dll;
	}
		
	public Node next()
		
		return c; 
	}
	
	public Node previous(){
		
	}
	
	public Object value(){
		
	}
	
	public String getTuple(){
		
	}
	
	public void remove(){
		
	}
	
}